import React from "react";
import { motion } from "framer-motion";
import { CheckCircle2, CalendarCheck2, ListTodo, Sparkles, Quote, Github, Twitter, Mail, ShieldCheck, Zap } from "lucide-react";

// Small helper for reveal-on-scroll animations
const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0 },
};

const Section = ({ id, children, className = "" }) => (
  <section id={id} className={`w-full py-20 md:py-28 ${className}`}>
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-6xl">{children}</div>
  </section>
);

const Badge = ({ children }) => (
  <span className="inline-flex items-center rounded-full border px-3 py-1 text-xs font-medium backdrop-blur-sm bg-white/40 dark:bg-white/10 border-white/50 shadow-sm">
    {children}
  </span>
);

const PrimaryButton = ({ children, href = "#pricing" }) => (
  <a
    href={href}
    className="inline-flex items-center justify-center rounded-2xl px-5 py-3 text-sm font-semibold shadow-lg shadow-black/5 ring-1 ring-black/10 bg-black text-white hover:scale-[1.02] active:scale-[.99] transition"
  >
    {children}
  </a>
);

const GhostButton = ({ children, href = "#features" }) => (
  <a
    href={href}
    className="inline-flex items-center justify-center rounded-2xl px-5 py-3 text-sm font-semibold ring-1 ring-black/10 hover:bg-black/5 transition"
  >
    {children}
  </a>
);

const Header = () => (
  <header className="sticky top-0 z-40 backdrop-blur bg-white/70 border-b border-black/10">
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-6xl">
      <nav className="flex items-center justify-between h-16">
        <div className="flex items-center gap-2 font-bold text-lg">
          <span className="inline-flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-500 via-blue-500 to-cyan-400 text-white shadow">TF</span>
          <span>TaskFlow</span>
        </div>
        <div className="hidden md:flex items-center gap-6 text-sm">
          <a href="#features" className="hover:opacity-70">Features</a>
          <a href="#reviews" className="hover:opacity-70">Reviews</a>
          <a href="#pricing" className="hover:opacity-70">Pricing</a>
          <a href="#contact" className="hover:opacity-70">Contact</a>
        </div>
        <div className="hidden md:block">
          <PrimaryButton>Get Started</PrimaryButton>
        </div>
      </nav>
    </div>
  </header>
);

const Hero = () => (
  <Section id="top" className="pt-10 md:pt-16 bg-gradient-to-b from-white to-slate-50">
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
      <motion.div
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, amount: 0.3 }}
        variants={fadeUp}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="space-y-6"
      >
        <Badge>
          <Sparkles className="h-3.5 w-3.5 mr-1.5" />
          New: Smart Scheduling
        </Badge>
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight">
          Organize your day with <span className="bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 via-blue-600 to-cyan-500">TaskFlow</span>
        </h1>
        <p className="text-slate-600 text-base sm:text-lg leading-relaxed max-w-xl">
          TaskFlow helps you capture todos, auto-prioritize what matters, and finish on time—without the chaos. Simple, fast, and delightfully organized.
        </p>
        <div className="flex flex-col sm:flex-row gap-3">
          <PrimaryButton href="#pricing">Start free</PrimaryButton>
          <GhostButton href="#features">See features</GhostButton>
        </div>
        <ul className="grid grid-cols-2 gap-3 text-sm text-slate-600">
          {[
            "Cross‑device sync",
            "Offline ready",
            "Drag & drop",
            "Calendar view",
          ].map((item) => (
            <li key={item} className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4" /> {item}
            </li>
          ))}
        </ul>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true, amount: 0.2 }}
        transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
        className="relative"
      >
        {/* Mocked app preview */}
        <div className="mx-auto w-full max-w-lg rounded-3xl border border-black/10 bg-white p-4 shadow-2xl">
          <div className="flex items-center justify-between border-b pb-3">
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <span className="inline-block h-2.5 w-2.5 rounded-full bg-green-500" /> Online
            </div>
            <Badge>Today · 4 Tasks</Badge>
          </div>
          <div className="space-y-3 pt-4">
            {[
              { icon: <ListTodo className="h-4 w-4" />, title: "Write project brief", meta: "Due 10:00 AM" },
              { icon: <CalendarCheck2 className="h-4 w-4" />, title: "Team stand‑up", meta: "10:30–10:45" },
              { icon: <ShieldCheck className="h-4 w-4" />, title: "Security review", meta: "Today" },
              { icon: <Zap className="h-4 w-4" />, title: "Ship sprint", meta: "This week" },
            ].map((t, i) => (
              <motion.div
                key={t.title}
                initial={{ opacity: 0, x: 12 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.45, ease: "easeOut", delay: i * 0.05 }}
                className="flex items-center justify-between rounded-2xl border border-black/10 p-3 hover:shadow-sm"
              >
                <div className="flex items-center gap-3">
                  <span className="inline-flex items-center justify-center h-8 w-8 rounded-xl bg-slate-100">{t.icon}</span>
                  <div>
                    <p className="font-medium">{t.title}</p>
                    <p className="text-xs text-slate-500">{t.meta}</p>
                  </div>
                </div>
                <input type="checkbox" className="h-4 w-4 rounded" />
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  </Section>
);

const features = [
  {
    icon: <ListTodo className="h-6 w-6" />,
    title: "Smart Tasks",
    desc: "Create, tag, and auto‑prioritize tasks with one tap.",
  },
  {
    icon: <CalendarCheck2 className="h-6 w-6" />,
    title: "Calendar View",
    desc: "Plan your week visually and drag tasks onto your schedule.",
  },
  {
    icon: <ShieldCheck className="h-6 w-6" />,
    title: "Privacy First",
    desc: "Local‑first storage with secure cloud backup options.",
  },
];

const Features = () => (
  <Section id="features">
    <motion.div
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, amount: 0.25 }}
      variants={fadeUp}
      transition={{ duration: 0.6 }}
      className="text-center max-w-2xl mx-auto"
    >
      <Badge>Features</Badge>
      <h2 className="mt-3 text-3xl sm:text-4xl font-bold">Everything you need to stay on track</h2>
      <p className="mt-3 text-slate-600">Built for speed, clarity, and focus.</p>
    </motion.div>

    <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {features.map((f, i) => (
        <motion.div
          key={f.title}
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5, delay: i * 0.05 }}
          className="rounded-3xl border border-black/10 p-6 bg-white shadow-sm hover:shadow-md"
        >
          <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-50">
            {f.icon}
          </div>
          <h3 className="mt-4 font-semibold text-lg">{f.title}</h3>
          <p className="mt-2 text-slate-600 text-sm">{f.desc}</p>
        </motion.div>
      ))}
    </div>
  </Section>
);

const testimonials = [
  {
    quote:
      "TaskFlow replaced three apps for me. I finish my day knowing what's done and what's next.",
    name: "Ayesha K.",
    role: "Product Manager",
  },
  {
    quote:
      "The calendar drag‑and‑drop is a game changer. Planning my week takes minutes, not hours.",
    name: "James R.",
    role: "Freelance Developer",
  },
  {
    quote:
      "Clean, fast, and focused. Exactly what my ADHD brain needed to stay on track.",
    name: "Noor F.",
    role: "Designer",
  },
];

const Reviews = () => (
  <Section id="reviews" className="bg-gradient-to-b from-slate-50 to-white">
    <motion.div
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, amount: 0.25 }}
      variants={fadeUp}
      transition={{ duration: 0.6 }}
      className="text-center max-w-2xl mx-auto"
    >
      <Badge>What users say</Badge>
      <h2 className="mt-3 text-3xl sm:text-4xl font-bold">Loved by focused teams & makers</h2>
      <p className="mt-3 text-slate-600">A few words from the people who get things done.</p>
    </motion.div>

    <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-6">
      {testimonials.map((t, i) => (
        <motion.figure
          key={t.name}
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5, delay: i * 0.05 }}
          className="rounded-3xl border border-black/10 bg-white p-6 shadow-sm"
        >
          <Quote className="h-6 w-6" />
          <blockquote className="mt-3 text-slate-700">{t.quote}</blockquote>
          <figcaption className="mt-4 text-sm text-slate-500">
            <span className="font-semibold text-slate-700">{t.name}</span> · {t.role}
          </figcaption>
        </motion.figure>
      ))}
    </div>
  </Section>
);

const plans = [
  {
    name: "Free",
    price: "$0",
    caption: "For personal to‑dos",
    features: ["Unlimited tasks", "1 project", "Mobile & Web"],
    cta: "Start free",
    highlight: false,
  },
  {
    name: "Pro",
    price: "$9",
    caption: "For power users",
    features: ["Unlimited projects", "Calendar & reminders", "File attachments"],
    cta: "Go Pro",
    highlight: true,
  },
  {
    name: "Team",
    price: "$15",
    caption: "For teams who ship",
    features: ["Shared workspaces", "Permissions", "Priority support"],
    cta: "Start team trial",
    highlight: false,
  },
];

const Pricing = () => (
  <Section id="pricing">
    <motion.div
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, amount: 0.25 }}
      variants={fadeUp}
      transition={{ duration: 0.6 }}
      className="text-center max-w-2xl mx-auto"
    >
      <Badge>Pricing</Badge>
      <h2 className="mt-3 text-3xl sm:text-4xl font-bold">Simple plans that scale with you</h2>
      <p className="mt-3 text-slate-600">Try everything free. Upgrade when you need more.</p>
    </motion.div>

    <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-6">
      {plans.map((p, i) => (
        <motion.div
          key={p.name}
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5, delay: i * 0.05 }}
          className={`rounded-3xl border p-6 shadow-sm ${
            p.highlight
              ? "bg-gradient-to-b from-indigo-600 to-blue-600 text-white border-transparent"
              : "bg-white border-black/10"
          }`}
        >
          <div className="flex items-baseline gap-2">
            <h3 className="text-xl font-semibold">{p.name}</h3>
            <span className={`text-xs px-2 py-0.5 rounded-full ${p.highlight ? "bg-white/20" : "bg-black/5"}`}>
              {p.caption}
            </span>
          </div>
          <p className={`mt-3 text-4xl font-extrabold tracking-tight ${p.highlight ? "text-white" : "text-slate-900"}`}>{p.price}<span className="text-base font-medium">/mo</span></p>
          <ul className={`mt-4 space-y-2 text-sm ${p.highlight ? "text-white/90" : "text-slate-600"}`}>
            {p.features.map((f) => (
              <li key={f} className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4" /> {f}
              </li>
            ))}
          </ul>
          <a
            href="#"
            className={`mt-6 inline-flex w-full items-center justify-center rounded-2xl px-4 py-2.5 text-sm font-semibold ring-1 transition ${
              p.highlight
                ? "bg-white text-indigo-700 ring-white/30 hover:bg-white/95"
                : "ring-black/10 hover:bg-black/5"
            }`}
          >
            {p.cta}
          </a>
        </motion.div>
      ))}
    </div>
  </Section>
);

const Footer = () => (
  <footer id="contact" className="border-t border-black/10 bg-white">
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-6xl py-10">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-start">
        <div>
          <div className="flex items-center gap-2 font-bold text-lg">
            <span className="inline-flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-500 via-blue-500 to-cyan-400 text-white shadow">TF</span>
            <span>TaskFlow</span>
          </div>
          <p className="mt-3 text-sm text-slate-600 max-w-xs">Plan, prioritize, and ship work that matters. Built with love for makers and teams.</p>
        </div>
        <div className="text-sm">
          <p className="font-semibold">Contact</p>
          <ul className="mt-3 space-y-2 text-slate-600">
            <li><a href="mailto:hello@taskflow.app" className="hover:opacity-70 inline-flex items-center gap-2"><Mail className="h-4 w-4" /> hello@taskflow.app</a></li>
            <li><a href="#" className="hover:opacity-70 inline-flex items-center gap-2"><Github className="h-4 w-4" /> GitHub</a></li>
            <li><a href="#" className="hover:opacity-70 inline-flex items-center gap-2"><Twitter className="h-4 w-4" /> Twitter</a></li>
          </ul>
        </div>
        <div className="text-sm">
          <p className="font-semibold">Legal</p>
          <ul className="mt-3 space-y-2 text-slate-600">
            <li><a href="#" className="hover:opacity-70">Privacy</a></li>
            <li><a href="#" className="hover:opacity-70">Terms</a></li>
            <li><a href="#" className="hover:opacity-70">Security</a></li>
          </ul>
        </div>
      </div>
      <div className="mt-8 text-xs text-slate-500">© {new Date().getFullYear()} TaskFlow, Inc. All rights reserved.</div>
    </div>
  </footer>
);

export default function TaskFlowLanding() {
  return (
    <div className="min-h-screen bg-white text-slate-900 antialiased">
      <Header />
      <main>
        <Hero />
        <Features />
        <Reviews />
        <Pricing />
      </main>
      <Footer />
    </div>
  );
}


