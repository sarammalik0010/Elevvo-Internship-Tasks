export default function Setting() {
  return <h2 className="text-2xl font-bold">⚙️ Settings Page</h2>;
}
