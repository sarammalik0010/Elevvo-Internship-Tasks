export default function Feedback() {
  return <h2 className="text-2xl font-bold">🏠 Feedback Page</h2>;
}
