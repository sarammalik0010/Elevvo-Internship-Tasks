export default function Home() {
  return <h2 className="text-2xl font-bold">🏠 Home Page</h2>;
}
