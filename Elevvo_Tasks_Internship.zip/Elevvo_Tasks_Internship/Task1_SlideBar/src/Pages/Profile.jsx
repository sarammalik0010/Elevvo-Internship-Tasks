export default function Profile() {
  return <h2 className="text-2xl font-bold">👤 Profile Page</h2>;
}
