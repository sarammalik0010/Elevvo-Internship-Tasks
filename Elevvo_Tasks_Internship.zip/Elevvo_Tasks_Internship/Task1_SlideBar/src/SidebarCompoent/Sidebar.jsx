import React, { useState } from "react";
import { Link } from "react-router-dom";

export default function Sidebar() {
  const [open, setOpen] = useState(true);

  return (
    <div
      className={`${
        open ? "w-64" : "w-16"
      } bg-gray-900 text-white h-screen p-4 transition-all duration-300 shadow-lg flex flex-col`}
    >
      {/* Toggle Button */}
      <button
        onClick={() => setOpen(!open)}
        className="bg-white text-gray-900 font-bold px-3 py-1 rounded hover:bg-gray-200 transition duration-300 mb-6"
      >
        {open ? "⏪" : "⏩"}
      </button>

      {/* Logo */}
      <div className="flex justify-center mb-6">
        <div className="bg-white w-12 h-12 rounded-full shadow-lg" />
      </div>

      {/* Navigation Links */}
      <ul className="space-y-4">
        <li>
          <Link
            to="/"
            className="flex items-center space-x-3 hover:bg-gray-700 px-3 py-2 rounded-md transition duration-300"
          >
            <span>🏠</span>
            {open && <span>Home</span>}
          </Link>
        </li>
        <li>
          <Link
            to="/profile"
            className="flex items-center space-x-3 hover:bg-gray-700 px-3 py-2 rounded-md transition duration-300"
          >
            <span>👤</span>
            {open && <span>Profile</span>}
          </Link>
        </li>
        <li>
          <Link
            to="/settings"
            className="flex items-center space-x-3 hover:bg-gray-700 px-3 py-2 rounded-md transition duration-300"
          >
            <span>⚙️</span>
            {open && <span>Settings</span>}
          </Link>
        </li>
        <li>
          <Link
            to="/feedback"
            className="flex items-center space-x-3 hover:bg-gray-700 px-3 py-2 rounded-md transition duration-300"
          >
            <span>✉️</span>
            {open && <span>Feedback</span>}
          </Link>
        </li>
      </ul>
    </div>
  );
}
