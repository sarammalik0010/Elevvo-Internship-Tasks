import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Sidebar from"./SidebarCompoent/Sidebar"
import Home from "./Pages/Home";
import Settings from "./Pages/Setting";
import Profile from "./Pages/Profile";
import Feedback from "./Pages/feedback";
export default function App() {
  return (
    <Router>
      <div className="flex">
        <Sidebar />
        <div className="flex-1 p-7">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/feedback" element={<Feedback />} />

          </Routes>
        </div>
      </div>
    </Router>
  );
}
