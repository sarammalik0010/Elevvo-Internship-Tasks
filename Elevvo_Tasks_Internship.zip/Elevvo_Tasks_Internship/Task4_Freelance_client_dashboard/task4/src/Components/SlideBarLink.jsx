import { NavLink } from "react-router-dom";
import { LayoutGrid, FolderKanban, UserCog } from "lucide-react";

export default function SlideBarLink() {
  const base =
    "flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors";
  const active = ({ isActive }) =>
    isActive
      ? `${base} bg-gray-800 text-white`
      : `${base} text-gray-300 hover:bg-gray-700 hover:text-white`;

  return (
    <nav className="flex flex-col space-y-2">
      <NavLink to="/" className={active} end>
        <LayoutGrid className="h-4 w-4" />
        Overview
      </NavLink>
      <NavLink to="/projects" className={active}>
        <FolderKanban className="h-4 w-4" />
        Projects
      </NavLink>
      <NavLink to="/profile" className={active}>
        <UserCog className="h-4 w-4" />
        Profile
      </NavLink>
    </nav>
  );
}
