import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { taskTypeBreakdown } from "../../Data/Mockdata";

const COLORS = ["#4F46E5", "#22C55E", "#F59E0B", "#EF4444"];

export default function TaskPieChart() {
  // Calculate total tasks for center label
  const total = taskTypeBreakdown.reduce((sum, item) => sum + item.value, 0);

  return (
    <div className="bg-white p-5 rounded-2xl shadow-md relative">
      <h3 className="text-lg font-bold mb-4">Task Breakdown</h3>

      {/* Wrapper with relative to contain absolute center text */}
      <div className="relative w-full h-80">
        <ResponsiveContainer>
          <PieChart>
            <Pie
              data={taskTypeBreakdown}
              dataKey="value"
              cx="40%" // push chart left to make space for legend
              cy="50%"
              innerRadius="50%"
              outerRadius="80%"
              paddingAngle={5}
              animationDuration={1200}
            >
              {taskTypeBreakdown.map((entry, i) => (
                <Cell key={`cell-${i}`} fill={COLORS[i % COLORS.length]} />
              ))}
            </Pie>

            {/* Tooltip */}
            <Tooltip
              formatter={(value, name) => [`${value} tasks`, name]}
              contentStyle={{
                backgroundColor: "#fff",
                borderRadius: "8px",
                border: "1px solid #ddd",
              }}
            />

            {/* Legend on right side */}
            <Legend
              layout="vertical"
              verticalAlign="middle"
              align="right"
              iconType="circle"
            />
          </PieChart>
        </ResponsiveContainer>

        {/* Center label (now inside chart container) */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <span className="text-xl font-bold text-gray-800">{total}</span>
          <span className="text-sm text-gray-500">Total Tasks</span>
        </div>
      </div>
    </div>
  );
}
