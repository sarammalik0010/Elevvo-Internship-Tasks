import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  LabelList,
  Legend,
} from "recharts";
import { earningsByMonth } from "../../Data/Mockdata";

export default function EarningsChart() {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart
        data={earningsByMonth}
        margin={{ top: 20, right: 20, left: 0, bottom: 10 }}
      >
        {/* Grid */}
        <CartesianGrid strokeDasharray="3 3" className="opacity-40" />

        {/* Axis */}
        <XAxis dataKey="month" tick={{ fontSize: 12 }} />
        <YAxis tick={{ fontSize: 12 }} />

        {/* Tooltip & Legend */}
        <Tooltip
          contentStyle={{
            backgroundColor: "#fff",
            borderRadius: "8px",
            border: "1px solid #ddd",
          }}
        />
        <Legend />

        {/* Gradient fill */}
        <defs>
          <linearGradient id="earningsGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#4F46E5" stopOpacity={0.9} />
            <stop offset="95%" stopColor="#4F46E5" stopOpacity={0.3} />
          </linearGradient>
        </defs>

        {/* Bar */}
        <Bar
          dataKey="earnings"
          fill="url(#earningsGradient)"
          radius={[8, 8, 0, 0]}
          animationDuration={1200}
        >
          <LabelList dataKey="earnings" position="top" fill="#333" fontSize={12} />
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
