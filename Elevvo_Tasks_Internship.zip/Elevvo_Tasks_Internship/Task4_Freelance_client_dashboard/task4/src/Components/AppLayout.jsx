import { useState } from "react";
import { Menu, X, Bell, ChevronDown, Search } from "lucide-react";
import SidebarLinks from "./SlideBarLink";

export default function AppLayout({ children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  return (
    <div className="flex h-screen bg-gray-100">
      {/* ===== Sidebar (Desktop) ===== */}
      <aside
        className={`hidden md:flex flex-col bg-gradient-to-b from-gray-900 to-gray-800 text-white shadow-lg transition-all duration-300 ${
          sidebarCollapsed ? "w-20" : "w-64"
        }`}
      >
        {/* Brand */}
        <div className="p-4 text-xl font-bold border-b border-gray-700 flex items-center justify-between">
          {!sidebarCollapsed && <span>FreelanceDash</span>}
          <button
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="text-gray-400 hover:text-white"
          >
            {sidebarCollapsed ? "➡" : "⬅"}
          </button>
        </div>

        {/* Links */}
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          <SidebarLinks collapsed={sidebarCollapsed} />
        </nav>
      </aside>

      {/* ===== Mobile Sidebar ===== */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 flex md:hidden">
          {/* Sidebar content */}
          <div className="w-64 bg-gray-900 text-white flex flex-col animate-slideIn">
            <div className="flex items-center justify-between p-4 border-b border-gray-700">
              <h2 className="text-lg font-bold">FreelanceDash</h2>
              <button onClick={() => setSidebarOpen(false)}>
                <X className="w-6 h-6" />
              </button>
            </div>
            <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
              <SidebarLinks />
            </nav>
          </div>
          {/* Background overlay */}
          <div
            className="flex-1 bg-black bg-opacity-50 animate-fadeIn"
            onClick={() => setSidebarOpen(false)}
          />
        </div>
      )}

      {/* ===== Main Content ===== */}
      <div className="flex-1 flex flex-col">
        {/* Topbar */}
        <header className="h-14 flex items-center justify-between px-4 shadow bg-white sticky top-0 z-40">
          {/* Left section */}
          <div className="flex items-center space-x-2">
            <button
              className="md:hidden p-2 rounded hover:bg-gray-200"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="w-6 h-6" />
            </button>
            <h1 className="text-xl font-semibold hidden sm:block">Dashboard</h1>
          </div>

          {/* Center: Search */}
          <div className="flex-1 max-w-md mx-4 hidden sm:flex">
            <div className="relative w-full">
              <input
                type="text"
                placeholder="Search..."
                className="w-full pl-10 pr-4 py-2 rounded-lg border focus:ring-2 focus:ring-indigo-500"
              />
              <Search className="w-5 h-5 text-gray-400 absolute left-3 top-2.5" />
            </div>
          </div>

          {/* Right section */}
          <div className="flex items-center space-x-4 relative">
            {/* Notifications */}
            <button
              className="relative p-2 rounded hover:bg-gray-100"
              onClick={() => setNotificationsOpen(!notificationsOpen)}
            >
              <Bell className="w-6 h-6 text-gray-600" />
              <span className="absolute top-1 right-1 bg-red-500 text-white text-xs px-1 rounded-full">
                3
              </span>
            </button>
            {notificationsOpen && (
              <div className="absolute right-0 top-12 bg-white shadow-lg rounded-lg w-64 p-3 z-50">
                <p className="font-semibold mb-2">Notifications</p>
                <ul className="space-y-2 text-sm">
                  <li className="p-2 hover:bg-gray-100 rounded">📌 New project assigned</li>
                  <li className="p-2 hover:bg-gray-100 rounded">💰 Payment received</li>
                  <li className="p-2 hover:bg-gray-100 rounded">✅ Task completed</li>
                </ul>
              </div>
            )}

            {/* User menu */}
            <div className="relative">
              <button
                onClick={() => setUserMenuOpen(!userMenuOpen)}
                className="flex items-center space-x-2 p-1 rounded hover:bg-gray-100"
              >
                <img
                  src="https://via.placeholder.com/32"
                  alt="User"
                  className="w-8 h-8 rounded-full"
                />
                <ChevronDown className="w-4 h-4 text-gray-500" />
              </button>
              {userMenuOpen && (
                <div className="absolute right-0 top-12 bg-white shadow-lg rounded-lg w-40 py-2 z-50">
                  <button className="block px-4 py-2 text-sm w-full text-left hover:bg-gray-100">
                    Profile
                  </button>
                  <button className="block px-4 py-2 text-sm w-full text-left hover:bg-gray-100">
                    Settings
                  </button>
                  <button className="block px-4 py-2 text-sm w-full text-left text-red-600 hover:bg-red-50">
                    Logout
                  </button>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-6">{children}</main>
      </div>
    </div>
  );
}

/* ==== Animations (add in global.css / tailwind.config if needed) ==== */
<style jsx global>{`
  .animate-slideIn {
    animation: slideIn 0.3s ease-out forwards;
  }
  @keyframes slideIn {
    from {
      transform: translateX(-100%);
    }
    to {
      transform: translateX(0);
    }
  }
  .animate-fadeIn {
    animation: fadeIn 0.3s ease-out forwards;
  }
  @keyframes fadeIn {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }
`}</style>
