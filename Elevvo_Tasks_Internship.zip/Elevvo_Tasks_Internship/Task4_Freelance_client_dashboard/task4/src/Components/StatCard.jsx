import { ArrowUpRight, ArrowDownRight, Info } from "lucide-react";
import { Tooltip } from "react-tooltip";

export default function StatCard({
  label,
  value,
  icon,
  trend,
  progress,
  color = "indigo",
  subtext,
  description,
  onClick,
}) {
  const isPositive = trend && trend.startsWith("+");

  // Tailwind color maps
  const colorMap = {
    indigo: "bg-indigo-100 text-indigo-600",
    green: "bg-green-100 text-green-600",
    orange: "bg-orange-100 text-orange-600",
    red: "bg-red-100 text-red-600",
    blue: "bg-blue-100 text-blue-600",
  };

  const gradientMap = {
    indigo: "from-indigo-400 to-indigo-600",
    green: "from-green-400 to-green-600",
    orange: "from-orange-400 to-orange-600",
    red: "from-red-400 to-red-600",
    blue: "from-blue-400 to-blue-600",
  };

  return (
    <div
      onClick={onClick}
      className={`bg-white p-5 rounded-2xl shadow-md flex flex-col justify-between cursor-pointer
                 hover:shadow-xl hover:-translate-y-1 transition-all duration-300`}
    >
      {/* Top section */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2">
            <p className="text-sm font-medium text-gray-500">{label}</p>
            {description && (
              <span data-tooltip-id={label}>
                <Info size={14} className="text-gray-400 hover:text-gray-600" />
              </span>
            )}
            {description && (
              <Tooltip id={label} place="top" content={description} />
            )}
          </div>
          <h4 className="text-3xl font-extrabold text-gray-800 mt-1">{value}</h4>

          {/* Trend */}
          {trend && (
            <div
              className={`flex items-center gap-1 text-sm font-semibold mt-1 ${
                isPositive ? "text-green-600" : "text-red-500"
              }`}
            >
              {isPositive ? (
                <ArrowUpRight size={16} />
              ) : (
                <ArrowDownRight size={16} />
              )}
              {trend}
            </div>
          )}

          {/* Subtext */}
          {subtext && (
            <p className="text-xs text-gray-500 mt-1 italic">{subtext}</p>
          )}
        </div>

        {/* Icon bubble */}
        {icon && (
          <div
            className={`flex items-center justify-center w-14 h-14 rounded-full shadow-inner
                        transform hover:scale-110 transition-all duration-300
                        ${colorMap[color]}`}
          >
            {icon}
          </div>
        )}
      </div>

      {/* Progress bar if provided */}
      {progress !== undefined && (
        <div className="mt-4">
          <div className="flex justify-between text-xs text-gray-500 mb-1">
            <span>Progress</span>
            <span>{progress}%</span>
          </div>
          <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
            <div
              className={`h-2 rounded-full bg-gradient-to-r ${gradientMap[color]}`}
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      )}
    </div>
  );
}
