import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import AppLayout from "./Components/AppLayout";
import OverviewPage from "./Pages/OverviewPage";
import ProjectsPage from "./Pages/ProjectPage";
import ProfilePage from "./Pages/ProfilePage";

export default function App() {
  return (
    <Router>
      <AppLayout>
        <Routes>
          <Route path="/" element={<OverviewPage />} />
          <Route path="/projects" element={<ProjectsPage />} />
          <Route path="/profile" element={<ProfilePage />} />
        </Routes>
      </AppLayout>
    </Router>
  );
}
