import { useState } from "react";
import { projectsSeed, statusColors } from "../Data/Mockdata";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Trash, Edit, Eye, FileDown } from "lucide-react";

export default function ProjectsPage() {
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [sortOrder, setSortOrder] = useState("asc");
  const [projects, setProjects] = useState(projectsSeed);
  const [showModal, setShowModal] = useState(false);
  const [editingProject, setEditingProject] = useState(null);

  // Filter & Sort
  const filtered = projects
    .filter((p) => p.name.toLowerCase().includes(query.toLowerCase()))
    .filter((p) => (statusFilter === "All" ? true : p.status === statusFilter))
    .sort((a, b) => {
      const da = new Date(a.deadline);
      const db = new Date(b.deadline);
      return sortOrder === "asc" ? da - db : db - da;
    });

  // Add / Edit Project
  const handleSave = (project) => {
    if (editingProject) {
      setProjects((prev) =>
        prev.map((p) => (p.id === editingProject.id ? { ...p, ...project } : p))
      );
    } else {
      setProjects((prev) => [...prev, { id: Date.now(), ...project }]);
    }
    setEditingProject(null);
    setShowModal(false);
  };

  // Delete Project
  const handleDelete = (id) => {
    if (confirm("⚠️ Are you sure you want to delete this project?")) {
      setProjects((prev) => prev.filter((p) => p.id !== id));
    }
  };

  // Export to CSV
  const exportCSV = () => {
    const csv = [
      ["Name", "Status", "Deadline"].join(","),
      ...projects.map((p) => [p.name, p.status, p.deadline].join(",")),
    ].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "projects.csv";
    link.click();
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6 flex items-center justify-between">
        Projects
        <div className="flex gap-2">
          <button
            onClick={() => setShowModal(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700"
          >
            <Plus size={18} /> Add Project
          </button>
          <button
            onClick={exportCSV}
            className="bg-gray-200 px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-gray-300"
          >
            <FileDown size={18} /> Export CSV
          </button>
        </div>
      </h2>

      {/* Search & Filters */}
      <div className="flex flex-col md:flex-row gap-3 mb-6">
        <input
          className="border rounded-lg p-2 flex-1 shadow-sm"
          placeholder="🔍 Search projects..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <select
          className="border rounded-lg p-2 shadow-sm"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option>All</option>
          <option>In Progress</option>
          <option>Completed</option>
          <option>Pending</option>
        </select>
        <select
          className="border rounded-lg p-2 shadow-sm"
          value={sortOrder}
          onChange={(e) => setSortOrder(e.target.value)}
        >
          <option value="asc">Sort by Deadline ↑</option>
          <option value="desc">Sort by Deadline ↓</option>
        </select>
      </div>

      {/* Projects Table */}
      <div className="overflow-x-auto">
        <table className="w-full border bg-white rounded-2xl shadow">
          <thead className="bg-gray-100 text-gray-700">
            <tr>
              <th className="text-left p-3">Name</th>
              <th className="text-left p-3">Status</th>
              <th className="text-left p-3">Deadline</th>
              <th className="text-left p-3">Progress</th>
              <th className="text-left p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((project) => (
              <tr
                key={project.id}
                className="border-t hover:bg-gray-50 transition"
              >
                <td className="p-3 font-medium">{project.name}</td>
                <td className="p-3">
                  <span
                    className={`px-3 py-1 rounded-full text-sm font-medium ${statusColors[project.status]}`}
                  >
                    {project.status}
                  </span>
                </td>
                <td className="p-3">{project.deadline}</td>
                <td className="p-3 w-40">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="h-2 bg-blue-600 rounded-full"
                      style={{
                        width:
                          project.status === "Completed"
                            ? "100%"
                            : project.status === "In Progress"
                            ? "60%"
                            : "20%",
                      }}
                    />
                  </div>
                </td>
                <td className="p-3 flex gap-3">
                  <button className="text-indigo-600 hover:underline flex items-center gap-1">
                    <Eye size={16} /> View
                  </button>
                  <button
                    onClick={() => {
                      setEditingProject(project);
                      setShowModal(true);
                    }}
                    className="text-green-600 hover:underline flex items-center gap-1"
                  >
                    <Edit size={16} /> Edit
                  </button>
                  <button
                    onClick={() => handleDelete(project.id)}
                    className="text-red-600 hover:underline flex items-center gap-1"
                  >
                    <Trash size={16} /> Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {filtered.length === 0 && (
          <p className="text-center text-gray-500 py-6">No projects found 🚫</p>
        )}
      </div>

      {/* Modal for Add/Edit */}
      <AnimatePresence>
        {showModal && (
          <motion.div
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.8 }}
              className="bg-white p-6 rounded-2xl shadow-lg w-full max-w-md"
            >
              <h3 className="text-lg font-semibold mb-4">
                {editingProject ? "Edit Project" : "Add New Project"}
              </h3>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  const data = new FormData(e.target);
                  handleSave({
                    name: data.get("name"),
                    status: data.get("status"),
                    deadline: data.get("deadline"),
                  });
                  e.target.reset();
                }}
                className="space-y-4"
              >
                <input
                  name="name"
                  placeholder="Project Name"
                  defaultValue={editingProject?.name || ""}
                  className="border rounded-lg p-2 w-full"
                />
                <select
                  name="status"
                  defaultValue={editingProject?.status || "Pending"}
                  className="border rounded-lg p-2 w-full"
                >
                  <option>In Progress</option>
                  <option>Completed</option>
                  <option>Pending</option>
                </select>
                <input
                  type="date"
                  name="deadline"
                  defaultValue={editingProject?.deadline || ""}
                  className="border rounded-lg p-2 w-full"
                />

                <div className="flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setShowModal(false);
                      setEditingProject(null);
                    }}
                    className="px-4 py-2 bg-gray-200 rounded-lg hover:bg-gray-300"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    Save
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
