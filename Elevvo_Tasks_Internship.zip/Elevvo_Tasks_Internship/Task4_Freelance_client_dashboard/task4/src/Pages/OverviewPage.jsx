import { ArrowUpRight, ArrowDownRight, Bell, CheckCircle, XCircle, Search } from "lucide-react";
import StatCard from "../Components/StatCard";
import EarningsChart from "../Components/Charts/EarningsChart";
import TaskPieChart from "../Components/Charts/TaskPieChart";
import { recentActivity } from "../Data/Mockdata";
import { motion } from "framer-motion";
import { Tooltip } from "react-tooltip";
import "react-tooltip/dist/react-tooltip.css";

export default function OverviewPage() {
  return (
    <div>
      {/* Title */}
      <h2 className="text-2xl font-bold mb-6">📊 Overview Dashboard</h2>

      {/* ====== Stat Cards ====== */}
      <div className="grid md:grid-cols-3 gap-6 mb-8">
        <StatCard
          label="Total Projects"
          value="12"
          icon={<ArrowUpRight className="text-green-500" />}
          trend="+15%"
          progress={75}
          color="blue"
        />
        <StatCard
          label="Earnings"
          value="$8,450"
          icon={<ArrowUpRight className="text-green-500" />}
          trend="+8%"
          progress={60}
          color="green"
        />
        <StatCard
          label="Tasks Due"
          value="5"
          icon={<ArrowDownRight className="text-red-500" />}
          trend="-2%"
          progress={40}
          color="red"
        />
      </div>

      {/* ====== Charts ====== */}
      <div className="grid md:grid-cols-2 gap-6 mb-8">
        <motion.div
          whileHover={{ scale: 1.02 }}
          className="bg-white p-6 rounded-2xl shadow hover:shadow-lg transition"
        >
          <h3 className="text-lg font-semibold mb-4">Monthly Earnings</h3>
          <EarningsChart />
        </motion.div>
        <motion.div
          whileHover={{ scale: 1.02 }}
          className="bg-white p-6 rounded-2xl shadow hover:shadow-lg transition"
        >
          <h3 className="text-lg font-semibold mb-4">Task Types</h3>
          <TaskPieChart />
        </motion.div>
      </div>

      {/* ====== Extra Panels ====== */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Recent Activity */}
        <motion.div
          whileHover={{ scale: 1.01 }}
          className="bg-white p-6 rounded-2xl shadow hover:shadow-lg transition"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Recent Activity</h3>
            <div className="flex items-center gap-2">
              <Search className="w-5 h-5 text-gray-500" data-tooltip-id="search-tip" />
              <Tooltip id="search-tip" content="Filter your activity logs" />
            </div>
          </div>

          <ul className="space-y-4">
            {recentActivity.map((item, idx) => (
              <li
                key={idx}
                className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 cursor-pointer transition"
              >
                <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center font-bold text-indigo-600">
                  {item[0]}
                </div>
                <div className="flex-1">
                  <p className="text-gray-800 font-medium">{item}</p>
                  <span className="text-xs text-gray-500">2 hrs ago</span>
                </div>
              </li>
            ))}
          </ul>
        </motion.div>

        {/* Notifications */}
        <motion.div
          whileHover={{ scale: 1.01 }}
          className="bg-white p-6 rounded-2xl shadow hover:shadow-lg transition"
        >
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Bell className="w-5 h-5 text-indigo-600" /> Notifications
          </h3>
          <ul className="space-y-4">
            <li className="p-3 bg-indigo-50 rounded-lg flex justify-between items-center hover:bg-indigo-100 transition">
              <span>New project proposal received</span>
              <div className="flex gap-2">
                <CheckCircle className="w-5 h-5 text-green-600 cursor-pointer" />
                <XCircle className="w-5 h-5 text-red-500 cursor-pointer" />
              </div>
            </li>
            <li className="p-3 bg-green-50 rounded-lg flex justify-between items-center hover:bg-green-100 transition">
              <span>Payment of $1,200 confirmed</span>
              <div className="flex gap-2">
                <CheckCircle className="w-5 h-5 text-green-600 cursor-pointer" />
                <XCircle className="w-5 h-5 text-red-500 cursor-pointer" />
              </div>
            </li>
            <li className="p-3 bg-yellow-50 rounded-lg flex justify-between items-center hover:bg-yellow-100 transition">
              <span>Task deadline approaching tomorrow</span>
              <div className="flex gap-2">
                <CheckCircle className="w-5 h-5 text-green-600 cursor-pointer" />
                <XCircle className="w-5 h-5 text-red-500 cursor-pointer" />
              </div>
            </li>
          </ul>
        </motion.div>
      </div>
    </div>
  );
}
