import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Eye, EyeOff, Github, Linkedin, Twitter, Download } from "lucide-react";

export default function ProfilePage() {
  const [tab, setTab] = useState("profile");
  const [profile, setProfile] = useState({
    name: "John Doe",
    email: "john@example.com",
    bio: "Frontend Developer passionate about React & UI/UX.",
    darkMode: false,
    notifications: true,
    twoFactor: false,
    github: "https://github.com/johndoe",
    linkedin: "https://linkedin.com/in/johndoe",
    twitter: "",
  });

  const [image, setImage] = useState(null);
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [message, setMessage] = useState(null);

  // Auto-dismiss notifications
  useEffect(() => {
    if (message) {
      const timer = setTimeout(() => setMessage(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [message]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setProfile((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) setImage(URL.createObjectURL(file));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setMessage({ type: "success", text: "✅ Changes saved successfully!" });
  };

  const handleDelete = () => {
    if (confirm("⚠️ Are you sure you want to delete your account? This cannot be undone.")) {
      setMessage({ type: "error", text: "❌ Account deleted" });
    }
  };

  const passwordStrength = () => {
    if (!password) return "";
    if (password.length < 6) return "Weak";
    if (/[A-Z]/.test(password) && /[0-9]/.test(password)) return "Strong";
    return "Medium";
  };

  const exportProfile = () => {
    const blob = new Blob([JSON.stringify(profile, null, 2)], {
      type: "application/json",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "profile.json";
    link.click();
  };

  return (
    <div
      className={`${
        profile.darkMode ? "bg-gray-900 text-white" : "bg-gray-50 text-gray-900"
      } p-6 rounded-xl min-h-screen`}
    >
      <h2 className="text-3xl font-bold mb-6">⚙️ Profile Settings</h2>

      {/* Tabs */}
      <div className="flex gap-4 mb-6">
        {["profile", "preferences", "security", "activity"].map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-5 py-2 rounded-lg transition ${
              tab === t
                ? "bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-lg"
                : "bg-gray-200 hover:bg-gray-300"
            }`}
          >
            {t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      {/* Notification */}
      <AnimatePresence>
        {message && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className={`mb-4 p-3 rounded-lg shadow ${
              message.type === "success"
                ? "bg-green-100 text-green-700"
                : "bg-red-100 text-red-700"
            }`}
          >
            {message.text}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Tabs Content */}
      <AnimatePresence mode="wait">
        {tab === "profile" && (
          <motion.form
            key="profile"
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -30 }}
            onSubmit={handleSubmit}
            className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow max-w-xl space-y-4"
          >
            {/* Profile Picture */}
            <div className="flex items-center gap-4">
              <img
                src={image || "https://via.placeholder.com/80"}
                alt="Profile"
                className="w-20 h-20 rounded-full border shadow"
              />
              <label className="cursor-pointer bg-indigo-600 text-white px-3 py-2 rounded text-sm">
                Upload Photo
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleImageUpload}
                />
              </label>
            </div>

            {/* Inputs */}
            <div>
              <label className="block mb-1 font-medium">Name</label>
              <input
                name="name"
                value={profile.name}
                onChange={handleChange}
                className="border rounded-lg p-2 w-full"
              />
            </div>
            <div>
              <label className="block mb-1 font-medium">Email</label>
              <input
                name="email"
                type="email"
                value={profile.email}
                onChange={handleChange}
                className="border rounded-lg p-2 w-full"
              />
            </div>
            <div>
              <label className="block mb-1 font-medium">Bio</label>
              <textarea
                name="bio"
                value={profile.bio}
                onChange={handleChange}
                rows="3"
                className="border rounded-lg p-2 w-full"
              />
            </div>

            {/* Social Links with icons */}
            <div className="flex gap-4">
              {profile.github && (
                <a
                  href={profile.github}
                  target="_blank"
                  className="text-gray-600 hover:text-black"
                >
                  <Github />
                </a>
              )}
              {profile.linkedin && (
                <a
                  href={profile.linkedin}
                  target="_blank"
                  className="text-blue-600 hover:text-blue-800"
                >
                  <Linkedin />
                </a>
              )}
              {profile.twitter && (
                <a
                  href={profile.twitter}
                  target="_blank"
                  className="text-sky-500 hover:text-sky-700"
                >
                  <Twitter />
                </a>
              )}
            </div>

            {/* Buttons */}
            <div className="flex gap-3">
              <button
                type="submit"
                className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition"
              >
                Save Changes
              </button>
              <button
                type="reset"
                className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={exportProfile}
                className="flex items-center gap-1 bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition"
              >
                <Download size={16} /> Export
              </button>
            </div>
          </motion.form>
        )}

        {tab === "preferences" && (
          <motion.div
            key="preferences"
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -30 }}
            className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow max-w-xl space-y-4"
          >
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                name="darkMode"
                checked={profile.darkMode}
                onChange={handleChange}
              />
              Dark Mode
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                name="notifications"
                checked={profile.notifications}
                onChange={handleChange}
              />
              Enable Notifications
            </label>

            <div
              className={`mt-4 p-4 rounded-xl shadow ${
                profile.darkMode
                  ? "bg-gray-900 text-white"
                  : "bg-gray-100 text-gray-800"
              }`}
            >
              <p className="font-semibold">Theme Preview</p>
              <p>
                This is how your dashboard will look in{" "}
                {profile.darkMode ? "Dark" : "Light"} Mode.
              </p>
            </div>
          </motion.div>
        )}

        {tab === "security" && (
          <motion.div
            key="security"
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -30 }}
            className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow max-w-xl space-y-4"
          >
            <div>
              <label className="block mb-1 font-medium">New Password</label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="border rounded-lg p-2 w-full"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-2 top-2 text-gray-500"
                >
                  {showPassword ? <EyeOff /> : <Eye />}
                </button>
              </div>
              {password && (
                <p
                  className={`text-sm mt-1 ${
                    passwordStrength() === "Weak"
                      ? "text-red-600"
                      : passwordStrength() === "Medium"
                      ? "text-yellow-600"
                      : "text-green-600"
                  }`}
                >
                  Strength: {passwordStrength()}
                </p>
              )}
            </div>

            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                name="twoFactor"
                checked={profile.twoFactor}
                onChange={handleChange}
              />
              Enable Two-Factor Authentication
            </label>

            <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition">
              Update Security
            </button>
          </motion.div>
        )}

        {tab === "activity" && (
          <motion.div
            key="activity"
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -30 }}
            className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow max-w-xl space-y-4"
          >
            <h3 className="text-lg font-semibold">Recent Activity</h3>
            <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
              <li>✅ Logged in from Chrome on Windows - 2 hrs ago</li>
              <li>🔒 Password changed - 3 days ago</li>
              <li>📍 Logged in from new device - 1 week ago</li>
            </ul>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Danger Zone */}
      <div className="mt-8 bg-red-50 dark:bg-red-900 p-6 rounded-2xl shadow max-w-xl">
        <h3 className="text-lg font-semibold text-red-600 dark:text-red-300">
          Danger Zone
        </h3>
        <p className="text-sm text-gray-600 dark:text-gray-400">
          Deleting your account is irreversible. All your projects and data will
          be lost.
        </p>
        <button
          onClick={handleDelete}
          className="mt-3 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition"
        >
          Delete Account
        </button>
      </div>
    </div>
  );
}
