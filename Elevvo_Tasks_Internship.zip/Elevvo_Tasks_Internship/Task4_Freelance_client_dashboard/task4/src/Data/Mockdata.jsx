export const earningsByMonth = [
  { month: "Jan", earnings: 400 },
  { month: "Feb", earnings: 800 },
  { month: "Mar", earnings: 600 },
  { month: "Apr", earnings: 1200 },
  { month: "May", earnings: 900 },
];

export const taskTypeBreakdown = [
  { name: "Design", value: 5 },
  { name: "Development", value: 8 },
  { name: "Testing", value: 3 },
];

export const projectsSeed = [
  { id: 1, name: "Website Redesign", status: "In Progress", deadline: "Sep 10" },
  { id: 2, name: "Mobile App", status: "Completed", deadline: "Aug 25" },
  { id: 3, name: "Logo Design", status: "Pending", deadline: "Sep 15" },
];

export const statusColors = {
  "In Progress": "text-yellow-600",
  Completed: "text-green-600",
  Pending: "text-gray-500",
};

export const recentActivity = [
  "Submitted proposal for Project A",
  "Received payment for Project B",
  "Updated profile information",
];
