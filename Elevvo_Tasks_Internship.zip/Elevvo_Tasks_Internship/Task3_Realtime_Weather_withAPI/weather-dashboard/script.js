const API_KEY = '92f6994f2a3c243b092b869b9f669bda'; // Replace with your OpenWeatherMap API key
const weatherDisplay = document.getElementById('weather-display');
const cityInput = document.getElementById('city-input');
const searchButton = document.getElementById('search-button');

async function getWeatherData(city) {
    weatherDisplay.innerHTML = '<p>Loading weather data...</p>';
    try {
        const currentWeatherUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`;
        const forecastUrl = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${API_KEY}&units=metric`;

        const [currentWeatherResponse, forecastResponse] = await Promise.all([
            fetch(currentWeatherUrl),
            fetch(forecastUrl)
        ]);

        if (!currentWeatherResponse.ok || !forecastResponse.ok) {
            throw new Error('City not found or API error');
        }

        const currentWeatherData = await currentWeatherResponse.json();
        const forecastData = await forecastResponse.json();

        displayWeather(currentWeatherData, forecastData);

    } catch (error) {
        console.error("Error fetching weather data:", error);
        weatherDisplay.innerHTML = `<p>${error.message}</p>`;
    }
}

async function getWeatherDataByCoords(latitude, longitude) {
    weatherDisplay.innerHTML = '<p>Loading weather data for your location...</p>';
    try {
        const currentWeatherUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=${API_KEY}&units=metric`;
        const forecastUrl = `https://api.openweathermap.org/data/2.5/forecast?lat=${latitude}&lon=${longitude}&appid=${API_KEY}&units=metric`;

        const [currentWeatherResponse, forecastResponse] = await Promise.all([
            fetch(currentWeatherUrl),
            fetch(forecastUrl)
        ]);

        if (!currentWeatherResponse.ok || !forecastResponse.ok) {
            throw new Error('Could not fetch weather data for your location.');
        }

        const currentWeatherData = await currentWeatherResponse.json();
        const forecastData = await forecastResponse.json();

        displayWeather(currentWeatherData, forecastData);

    } catch (error) {
        console.error("Error fetching weather data by coordinates:", error);
        weatherDisplay.innerHTML = `<p>${error.message}</p>`;
    }
}

function getUserLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                getWeatherDataByCoords(latitude, longitude);
            },
            (error) => {
                console.error("Error getting user location:", error);
                weatherDisplay.innerHTML = '<p>Geolocation denied or unavailable. Please enter a city manually.</p>';
            }
        );
    } else {
        weatherDisplay.innerHTML = '<p>Geolocation is not supported by your browser. Please enter a city manually.</p>';
    }
}

function displayWeather(current, forecast) {
    weatherDisplay.innerHTML = `
        <div class="current-weather">
            <h2>${current.name}, ${current.sys.country}</h2>
            <img src="http://openweathermap.org/img/wn/${current.weather[0].icon}@2x.png" alt="Weather icon">
            <p class="temperature">${Math.round(current.main.temp)}°C</p>
            <p class="description">${current.weather[0].description}</p>
            <div class="details">
                <div>
                    <p>Humidity:</p>
                    <p>${current.main.humidity}%</p>
                </div>
                <div>
                    <p>Wind:</p>
                    <p>${current.wind.speed} m/s</p>
                </div>
            </div>
        </div>
        <h3>3-Day Forecast</h3>
        <div class="forecast-days">
            ${getForecastDays(forecast)}
        </div>
    `;
}

function getForecastDays(forecast) {
    const dailyForecasts = forecast.list.filter(item => item.dt_txt.includes('12:00:00'));
    return dailyForecasts.slice(0, 3).map(day => `
        <div class="forecast-day">
            <p class="day">${new Date(day.dt * 1000).toDateString()}</p>
            <img src="http://openweathermap.org/img/wn/${day.weather[0].icon}.png" alt="Weather icon">
            <p class="temp">${Math.round(day.main.temp)}°C</p>
            <p>${day.weather[0].description}</p>
        </div>
    `).join('');
}

searchButton.addEventListener('click', () => {
    const city = cityInput.value.trim();
    if (city) {
        getWeatherData(city);
    }
});

cityInput.addEventListener('keypress', (event) => {
    if (event.key === 'Enter') {
        const city = cityInput.value.trim();
        if (city) {
            getWeatherData(city);
        }
    }
});

// Fetch weather for user's location on load
getUserLocation();
