# Real-Time Weather Dashboard

This project creates a real-time weather dashboard that displays current weather data and a 3-day forecast for multiple cities, including support for the user's current location.

## Features

*   **Current Weather:** Displays temperature, weather description, and an icon.
*   **3-Day Forecast:** Shows daily temperature and weather icons for the next three days.
*   **Search Functionality:** Allows users to search for weather data in different cities.
*   **Geolocation Support:** Automatically fetches weather data for the user's current location on load.
*   **Loading States:** Provides visual feedback during data fetching.
*   **Responsive Design:** Adapts to different screen sizes for a clean and minimal UI.

## Setup and Installation

1.  **Clone the repository (or create the files manually):**
    ```bash
    # If you're cloning
    git clone <repository-url>
    cd weather-dashboard

    # If you're creating files manually, ensure you have:
    # - index.html
    # - style.css
    # - script.js
    ```

2.  **Get an OpenWeatherMap API Key:**
    *   Go to [OpenWeatherMap](https://openweathermap.org/api).
    *   Sign up for a free account.
    *   Navigate to the "API keys" tab and generate a new API key.

3.  **Update the API Key in `script.js`:**
    Open `weather-dashboard/script.js` and replace `'YOUR_API_KEY'` with your actual OpenWeatherMap API key:

    ```javascript
    const API_KEY = 'YOUR_API_KEY'; // Replace with your OpenWeatherMap API key
    ```

4.  **Open `index.html`:**
    Simply open the `index.html` file in your web browser. The dashboard should load, and if you grant permission, it will automatically fetch weather data for your current location. You can also use the search bar to look up other cities.

## Project Structure

```
weather-dashboard/
├── index.html
├── style.css
└── script.js
```
